class PaginationModel {
  int page;
  int limit;

  PaginationModel({required this.page, required this.limit});
}
