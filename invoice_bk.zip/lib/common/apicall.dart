import 'package:flutter_application_1/common/apimodal.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

Future<List> login(username, password) async {
  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'username': username,
      'key': password,
      'report_action': 'userlogin',
    },
  );

  if (response.statusCode == 200) {
    // String data = response.body;
    // var data = [];
    // List<Map<String, dynamic>> send=[] ;
    var usersdata = jsonDecode(response.body);
    var send = [usersdata];
    return send;
    // return logindata.fromJson(jsonDecode(response.body));
    // throw Exception('Failed to load login');
  } else {
    throw Exception('Failed to load login');
  }
}

Future<Album> fetchAlbum() async {
  final response = await http
      .get(Uri.parse('https://jsonplaceholder.typicode.com/albums/1'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return Album.fromJson(jsonDecode(response.body));
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load album');
  }
}

// Future<http.Response> login(username, password) async {
//   return http.post(
//     Uri.parse('https://kingzquest.com/invoice/api/api.php'),
//     headers: <String, String>{
//       'Content-Type': 'application/json; charset=UTF-8',
//     },
//     body: <String, String>{'username': username, 'key': password},
//   );
// }

// Future<logindata> masterlogin(
//     name,
//     email,
//     address,
//     phonenumber,
//     distric,
//     state,
//     username,
//     password,
//     refferd,
//     fee_amount,
//     Payment_type,
//     date_range_picker,
//     num_companies,
//     paid,
//     status,
//     description)
Future<logindata> masterlogin(formvalues) async {
  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'report_action': 'master_login',
      'formvalues': formvalues,
      'formsubmit': 'master_login',
    },
    // body: {
    //   'name': name,
    //   'email': email,
    //   'address': address,
    //   'phonenumber': phonenumber,
    //   'distric': distric,
    //   'state': state,
    //   'username': username,
    //   'password': password,
    //   'refferd': refferd,
    //   'fee_amount': fee_amount,
    //   'Payment_type': Payment_type,
    //   'date_range_picker': date_range_picker,
    //   'num_companies': num_companies,
    //   'paid': paid,
    //   'status': status,
    //   'description': description,
    //   'report_action': 'master_login',
    //   'formsubmit': 'master_login',
    // },
  );
  print("okay");
  print(response.body);
  if (response.statusCode == 200) {
    // print("okayyy");
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return logindata.fromJson(jsonDecode(response.body));
    // return response.body;
    // throw Exception('Failed to load login');
  } else {
    // print("noooo");
    // print(response);
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load login');
  }
}

String loginuserid = '';
Future<logindata> Companylogin(formvalues) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  loginuserid = prefs.getString('user_id').toString();

  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'report_action': 'company_login',
      'master': loginuserid,
      'formvalues': formvalues,
      'formsubmit': 'company_login',
    },
    // body: {
    //   'name': name,
    //   'email': email,
    //   'address': address,
    //   'phonenumber': phonenumber,
    //   'distric': distric,
    //   'state': state,
    //   'username': username,
    //   'password': password,
    //   'refferd': refferd,
    //   'fee_amount': fee_amount,
    //   'Payment_type': Payment_type,
    //   'date_range_picker': date_range_picker,
    //   'num_companies': num_companies,
    //   'paid': paid,
    //   'status': status,
    //   'description': description,
    //   'report_action': 'master_login',
    //   'formsubmit': 'master_login',
    // },
  );
  // print("okay");
  // print(response.body);
  if (response.statusCode == 200) {
    // print("okayyy");
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return logindata.fromJson(jsonDecode(response.body));
    // return response.body;
    // throw Exception('Failed to load login');
  } else {
    // print("noooo");
    // print(response);
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load login');
  }
}

Future<logindata> Userlogin(formvalues, companyid) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  loginuserid = prefs.getString('user_id').toString();

  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'report_action': 'usercreatelogin',
      'master': loginuserid,
      'formvalues': formvalues,
      'formsubmit': 'usercreatelogin',
      'company': companyid,
    },
    // body: {
    //   'name': name,
    //   'email': email,
    //   'address': address,
    //   'phonenumber': phonenumber,
    //   'distric': distric,
    //   'state': state,
    //   'username': username,
    //   'password': password,
    //   'refferd': refferd,
    //   'fee_amount': fee_amount,
    //   'Payment_type': Payment_type,
    //   'date_range_picker': date_range_picker,
    //   'num_companies': num_companies,
    //   'paid': paid,
    //   'status': status,
    //   'description': description,
    //   'report_action': 'master_login',
    //   'formsubmit': 'master_login',
    // },
  );
  // print("okay");
  // print(response.body);
  if (response.statusCode == 200) {
    // print("okayyy");
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return logindata.fromJson(jsonDecode(response.body));
    // return response.body;
    // throw Exception('Failed to load login');
  } else {
    // print("noooo");
    // print(response);
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load login');
  }
}

String loginrole = '';
Future<logindata> itemcreation(formvalues) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  loginuserid = prefs.getString('user_id').toString();
  loginrole = prefs.getString('role').toString();

  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'report_action': 'item_create',
      'master': loginuserid,
      'role': loginrole,
      'formvalues': formvalues,
      'formsubmit': 'itemcreate',
    },
  );

  if (response.statusCode == 200) {
    return logindata.fromJson(jsonDecode(response.body));
  } else {
    throw Exception('Failed to load login');
  }
}

Future<logindata> customercreation(formvalues) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();

  loginuserid = prefs.getString('user_id').toString();
  loginrole = prefs.getString('role').toString();

  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'report_action': 'create_customer',
      'master': loginuserid,
      'role': loginrole,
      'formvalues': formvalues,
      'formsubmit': 'create_customer',
    },
  );

  if (response.statusCode == 200) {
    return logindata.fromJson(jsonDecode(response.body));
  } else {
    throw Exception('Failed to load login');
  }
}

Future<logindata> saleslogin(formvalues) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  print('send');
  loginuserid = prefs.getString('user_id').toString();

  final response = await http.post(
    Uri.parse('https://kingzquest.com/invoice/api/api.php'),
    body: {
      'report_action': 'save_sales_invoice',
      'master': loginuserid,
      'formvalues': formvalues,
      'formsubmit': 'save_sales_invoice',
    },
  );
  // print("okay");
  print(response.body);
  if (response.statusCode == 200) {
    // print("okayyy");
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return logindata.fromJson(jsonDecode(response.body));
    // return response.body;
    // throw Exception('Failed to load login');
  } else {
    // print("noooo");
    // print(response);
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load login');
  }
}
