import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/customers/list/model/card_model.dart';

// Widget okButton = TextButton(
//   child: Text("OK"),
//   onPressed: () => Navigator.pop(context, false),
// );

class CardItemView extends StatelessWidget {
  final CardModel card;
  // CardItemView(this.card);
  const CardItemView({Key? key, required this.card}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 24.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      elevation: 5,
      child: Column(
        children: [
          ListTile(
            title: Text(card.name),
            onTap: () {
              // AlertDialog alert = AlertDialog(
              //   title: Text(card.username),
              //   content: Text('H=${card.height} / W=${card.width}'),
              //   actions: [
              //     TextButton(
              //       child: Text("OK"),
              //       onPressed: () => Navigator.pop(context, false),
              //     ),
              //   ],
              // );
              // showDialog(
              //   context: context,
              //   builder: (BuildContext context) {
              //     return alert;
              //   },
              // );
            },
            subtitle: Text(card.phone),
            trailing: Wrap(
              spacing: 12, // space between two icons
              children: <Widget>[
                // IconButton(
                //   icon: Icon(Icons.edit),
                //   onPressed: () {},
                // ),
                IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {},
                ),
              ],
            ),
            // trailing:  IconButton(
            //   icon: Icon(Icons.edit),
            //   onPressed: () {},
            // ),
          ),
        ],
      ),
    );
  }

  // ListTile get _buildDescriptionItem {
  //   return ListTile(
  //     title: Text(card.author),
  //     onTap: () => Scaffold.of(context)
  //         .showSnackBar(SnackBar(content: Text(card.width.toString()))),
  //     subtitle: Text('H=${card.height} / W=${card.width}'),
  //     trailing: Wrap(
  //       spacing: 12, // space between two icons
  //       children: <Widget>[
  //         IconButton(
  //           icon: Icon(Icons.edit),
  //           onPressed: () {},
  //         ),
  //         IconButton(
  //           icon: Icon(Icons.delete),
  //           onPressed: () {},
  //         ),
  //       ],
  //     ),
  //     // trailing:  IconButton(
  //     //   icon: Icon(Icons.edit),
  //     //   onPressed: () {},
  //     // ),
  //   );
  // }

  SizedBox get _buildImageItem {
    return SizedBox(
      height: 150,
      width: double.infinity,
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
        // child: Image.network(
        //   card.downloadUrl,
        //   fit: BoxFit.cover,
        // ),
      ),
    );
  }
}
